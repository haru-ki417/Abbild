﻿window.nkMedia =
{
    GetCurrentSrc: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        return me.currentSrc;
    },

    GetCurrentTime: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        return me.currentTime;
    },
    
    GetEnded: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        return me.ended;
    },
    
    GetPaused: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        return me.paused;
    },

    GetSrc: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        return me.src;
    },
    SetSrc: function(uid, module, d)
    {
        var me = nkJSObject.GetObject(uid);
        var sr = nkJSObject.ReadString(module, d+ 0);
        me.src = sr;
    },
    
    GetMuted: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        return me.muted;
    },
    SetMuted: function(uid, module, d)
    {
        var me = nkJSObject.GetObject(uid);
        var mu = module.HEAP32[(d+ 0)>>2];
        me.muted = mu !== 0;
    },
    
    GetLoop: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        return me.loop;
    },
    SetLoop: function(uid, module, d)
    {
        var me = nkJSObject.GetObject(uid);
        var lo = module.HEAP32[(d+ 0)>>2];
        me.loop = lo !== 0;
    },
    
    GetVolume: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        return me.volume;
    },
    SetVolume: function(uid, module, d)
    {
        var me = nkJSObject.GetObject(uid);
        var vo = module.HEAPF32[(d+ 0)>>2];
        me.volume = vo;
    },
    
    Load: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        me.load();
    },
    Play: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        var pm = me.play();
    },
    Pause: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
         me.pause();
        return;
    },
    
    RegisterEvents: function(uid)
    {
        var bs = nkJSObject.GetObject(uid);

        bs.onended = function(event)
        {
            DotNet.invokeMethod('nkast.Wasm.Dom', 'JsMediaOnEnded', uid);
        };
        bs.onplaying = function(event)
        {
            DotNet.invokeMethod('nkast.Wasm.Dom', 'JsMediaOnPlaying', uid);
        };
        bs.ontimeupdate = function(event)
        {
            DotNet.invokeMethod('nkast.Wasm.Dom', 'JsMediaOnOnTimeUpdate', uid);
        };
    },
    UnregisterEvents: function(uid)
    {
        var me = nkJSObject.GetObject(uid);
        me.onended = null;
        me.onplaying = null;
        me.ontimeupdate = null;
    }
};

window.nkAudio =
{
    Create: function(uid)
    {
        var au = new Audio();
        return nkJSObject.RegisterObject(au);
    }
};

window.nkVideo =
{
    Create: function(uid)
    {
        var vi = document.createElement("video");
        return nkJSObject.RegisterObject(vi);
    }
};

